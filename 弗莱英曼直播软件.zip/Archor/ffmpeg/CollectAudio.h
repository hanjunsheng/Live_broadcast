#pragma once
#ifndef COLLECTAUDIO_H__
#define COLLECTAUDIO_H__

#include "AudioEncode.h"

#include <iostream>
#include <Mmdeviceapi.h>
#include <Mmsystem.h>
#include <Mmreg.h>
#include <Audioclient.h>
#include <Avrt.h>
#include <process.h>
using namespace std;

#pragma comment(lib,"Winmm.lib")
#pragma comment(lib,"Avrt.lib")

typedef struct AUDIOSTRUCT
{
	IMMDevice * pMMDevice;
    bool bInt16;
    HANDLE hStartedEvent;
    HANDLE hStopEvent;
    UINT32 pnFrames;
}AudioStruct;


class CCollectAudio
{
public:
	CCollectAudio(void);
	~CCollectAudio(void);
//�̺߳���
public:
	static DWORD WINAPI ThreadSound(LPVOID lpParameter);
	HANDLE m_hStartedEvent;
    HANDLE m_hStopEvent;
	HANDLE m_threadsound;
//¼��
public:
	IMMDevice * m_pMMDevice;
	IMMDevice* GetDefaultDevice();
	bool m_bflagchangefile;
	HRESULT CollectAudio(IMMDevice *pMMDevice,bool bInt16,HANDLE hStartedEvent,HANDLE hStopEvent,PUINT32 pnFrames);
	HMMIO file;
//AAC������
public:
	CAudioEncode myaudioencode;
	HANDLE m_hthreadaudioendoce;
	HANDLE m_eventaudioencode;
	static DWORD WINAPI Threadaudioencode(LPVOID lpParameter);
	bool m_bflagfinishaudio;
//��װ����
	void Initial();
	void Run();
	void Close();
	void Destroy();
};

#endif