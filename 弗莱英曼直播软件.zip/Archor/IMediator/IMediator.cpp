#include "stdafx.h"
#include "IMediator.h"

 CIMediator:: CIMediator()
{
}

 CIMediator::~ CIMediator()
{
}