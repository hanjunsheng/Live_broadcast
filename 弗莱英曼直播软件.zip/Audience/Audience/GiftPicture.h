#pragma once


// CGiftPicture

class CGiftPicture1 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture1)

public:
	CGiftPicture1();
	virtual ~CGiftPicture1();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};

class CGiftPicture2 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture2)

public:
	CGiftPicture2();
	virtual ~CGiftPicture2();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};

class CGiftPicture3 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture3)

public:
	CGiftPicture3();
	virtual ~CGiftPicture3();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};

class CGiftPicture4 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture4)

public:
	CGiftPicture4();
	virtual ~CGiftPicture4();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};

class CGiftPicture5 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture5)

public:
	CGiftPicture5();
	virtual ~CGiftPicture5();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};

class CGiftPicture6 : public CStatic
{
	DECLARE_DYNAMIC(CGiftPicture6)

public:
	CGiftPicture6();
	virtual ~CGiftPicture6();

protected:
	DECLARE_MESSAGE_MAP()
	HBITMAP hbitmap;
	HBITMAP hbitmappre;
	bool m_bMouseTrack;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnStnClicked();
};


